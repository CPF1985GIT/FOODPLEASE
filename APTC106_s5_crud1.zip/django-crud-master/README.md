
Crear un entorno virtual para poder seguir trabajando con el proyecto

Ver el archivo requiremets.txt para bajar los componentes necesarios para 
poder trabajar el proyecto

pip install -r requeriments.tx 

con el comando anterior bajamos las dependencias necesarias
